This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.133-4c60fddb171a
  Created at 2024/11/02 13:44:04

This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.134-952ae203dbbe
  Created at 2025/03/31 17:31:35
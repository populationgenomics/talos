This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.134-952ae203dbbe
  Created at 2025/08/06 12:51:26